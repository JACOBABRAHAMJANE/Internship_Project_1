package com.example.gym.options

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.gym.R
import com.example.gym.SharedViewModel
import com.example.gym.ui.theme.GYMTheme
//-------------------------------------------------------------
@Composable
fun Option7(navController: NavController, viewModel: SharedViewModel)
{
    val pcolor = colorResource(id = R.color.white)
    var selected by remember { mutableStateOf("") }
    var t1 = "1 time/week"
    var t2  = "2 time/week"
    var t3 = "3 time/week"
    var t4 ="4 time/week"

    Column (
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(top = 170.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    )
    {
        Text(text = " 8how often do you workout", fontSize = 24.sp,
            textDecoration = TextDecoration.Underline)
        Spacer(modifier = Modifier.padding(top = 25.dp))
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(pcolor,
                    shape = androidx.compose.foundation.shape.RoundedCornerShape( topStart = 60.dp, topEnd = 60.dp))
                .padding(top = 30.dp),
            horizontalAlignment = Alignment.CenterHorizontally,

            ){
            Spacer( modifier = Modifier.padding(top = 50.dp))

            Text( text = t1, fontSize = 20.sp,
                color = if (selected == t1) Color(0xFF7A20C9)
                else Color(0xFF000000),
                modifier = Modifier
                    .clickable{selected = t1
                    viewModel.ofWorkoutValue( t1)}
                //  .background(Color.White,shape = RoundedCornerShape(20.dp))
                //  .border(1.5.dp, Color(0xFF595050),shape = RoundedCornerShape(20.dp))
            )
            Spacer( modifier = Modifier.padding(top = 50.dp))

            Text( text = t2, fontSize = 20.sp,
                color = if (selected == t2) Color(0xFF7A20C9)
                else Color(0xFF000000),
                modifier = Modifier
                    .clickable{selected = t2
                    viewModel.ofWorkoutValue(t2)}
                //  .background(Color.White,shape = RoundedCornerShape(20.dp))
                //  .border(1.5.dp, Color(0xFF595050),shape = RoundedCornerShape(20.dp))
            )
            Spacer( modifier = Modifier.padding(top = 50.dp))

            Text( text = t3, fontSize = 20.sp,
                color = if (selected == t3) Color(0xFF7A20C9)
                else Color(0xFF000000),
                modifier = Modifier
                    .clickable{selected = t3
                    viewModel.ofWorkoutValue(t3)}
                //  .background(Color.White,shape = RoundedCornerShape(20.dp))
                /*  .border(1.5.dp, Color(0xFF595050),
                      shape = RoundedCornerShape(20.dp))
                  .height(40.dp)*/
            )
            Spacer( modifier = Modifier.padding(top = 50.dp))
            Text( text = t4, fontSize = 20.sp,
                color = if (selected == t4) Color(0xFF7A20C9)
                else Color(0xFF000000),
                modifier = Modifier
                    .clickable{selected = t4
                    viewModel.ofWorkoutValue(t4)}
                //  .background(Color.White,shape = RoundedCornerShape(20.dp))
                /*  .border(1.5.dp, Color(0xFF595050),
                      shape = RoundedCornerShape(20.dp))
                  .height(40.dp)*/
            )
            Spacer( modifier = Modifier.padding(top = 50.dp))



            Image(
                painter = painterResource(id = R.drawable.img_next),
                contentDescription = "next",
                modifier = Modifier
                    .size(150.dp)
                    .padding(top = 100.dp)
                    .clickable{ navController.navigate("option_8") }
            )


        }
    }
}
//-------------------------------------------------------
//preview
@Preview
@Composable
fun Option7Preview(){
    GYMTheme {
        val navController = rememberNavController()
        Option7(navController = navController, viewModel = SharedViewModel())
    }
}