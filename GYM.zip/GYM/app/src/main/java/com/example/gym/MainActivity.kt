package com.example.gym

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
//import androidx.compose.foundation.rememberScrollState
//import androidx.compose.foundation.verticalScroll
//import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.gym.main.Main_page
import com.example.gym.main.Main_page_1
import com.example.gym.main.Main_page_2
import com.example.gym.main.Main_page_3
import com.example.gym.main.Main_page_4
import com.example.gym.main.Main_page_5
import com.example.gym.options.Option1
import com.example.gym.options.Option2
import com.example.gym.options.Option3
import com.example.gym.options.Option4
import com.example.gym.options.Option5
import com.example.gym.options.Option6
import com.example.gym.options.Option7
import com.example.gym.options.Option8
import com.example.gym.options.Plan_page
import com.example.gym.options.StartOption
import com.example.gym.ui.theme.GYMTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class MainActivity : ComponentActivity() {
    private val sharedViewModel: SharedViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GYMTheme {
                val navController = rememberNavController()
                NavHost(
                    navController = navController,
                    startDestination = "welcome"
                ) { // Set startDestination to "welcome"
                    composable("welcome")     { WelcomeScreen(navController) }
                    composable("Signing")     { SignUpScreen(navController)  }
                    composable("login")       { LoginupScreen(navController) }
                    composable("option_start"){ StartOption(navController) }
                    composable("option_1")    { Option1(navController,sharedViewModel) }
                    composable("option_2")    { Option2(navController) }
                    composable("option_3")    { Option3(navController) }
                    composable("option_4")    { Option4(navController) }
                    composable("option_5")    { Option5(navController) }
                    composable("option_6")    { Option6(navController) }
                    composable("option_7")    { Option7(navController) }
                    composable("option_8")    { Option8(navController,sharedViewModel) }
                    composable("option_9")    { Plan_page(navController) }
                    composable("m_page")      { Main_page(navController) }
                    composable("m_page1")     { Main_page_1(navController) }
                    composable("m_page2")     { Main_page_2(navController) }
                    composable("m_page3")     { Main_page_3(navController) }
                    composable("m_page4")     { Main_page_4(navController) }
                    composable("m_page5")     { Main_page_5(navController) }
                }
            }
        }
    }
}
//-----------------------
class SharedViewModel : ViewModel() {
    private val _optionvalues = MutableStateFlow("")
    val optionvalues: StateFlow<String> = _optionvalues

    fun setGender(value: String) {
        _optionvalues.value = value
    }
}
//---------------------------------

@Composable
fun WelcomeScreen(navController: NavController) {
    Box(modifier = Modifier.fillMaxSize()) {
        // Background Image
        Image(
            painter = painterResource(id = R.drawable.startedpage1),
            contentDescription = "Background Image",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Centered Texts
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 100.dp, vertical = 250.dp)
                .padding(top = 10.dp, bottom = 50.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Welcome",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Light,
                modifier = Modifier.padding(end = 50.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "To",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Light
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Pro Fitness",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Light,
                modifier = Modifier.padding(start = 25.dp)
            )
        }

        // Get Started Button
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 300.dp, bottom = 100.dp)
                .padding(horizontal = 100.dp, vertical = 50.dp),
            contentAlignment = Alignment.Center,
        ) {
            Button(onClick = { navController.navigate("Signing") }) { // Add the button here
                Text("Get Started")
            }
            /*Scaffold { innerPadding ->
                NavHost(
                    navController = navController,
                    startDestination = "Signing", // Assuming "signing" is the intended start
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(innerPadding)
                ) {
                    composable(route = "Signing") { // Corrected route
                        SigningPreview() // Display the sign-in screen
                    }
                    composable(route = "main") { // Corrected route
                        WelcomeScreen() // Display the main activity screen
                    }
                }
            }*/
            }
        }
    }



@Preview(showBackground = true)
@Composable
fun WelcomeScreenPreview() {
    GYMTheme {
        val navController = rememberNavController() // Create a NavController
        WelcomeScreen(navController = navController) // Pass it to WelcomeScreen
    }
}