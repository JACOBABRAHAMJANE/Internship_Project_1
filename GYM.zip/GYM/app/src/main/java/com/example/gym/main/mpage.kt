package com.example.gym.main


import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import com.example.gym.R
import com.example.gym.ui.theme.GYMTheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

//-------------------------------------------------------------

/*@Composable
fun Navigation_pages() {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = "m_page1"
    ) {
        composable("m_page1") { Main_page_1(navController) }
        composable("m_page2") { Main_page_2(navController) }
        composable("m_page3") { Main_page_3(navController) }
        composable("m_page4") { Main_page_4(navController) }
        composable("m_page5") { Main_page_5(navController) }
    }
}*/
@Composable
fun Main_page(navController: NavController)
{
    val color = colorResource(id = R.color.black1)
   // val nav = Navigation_pages()
    Column (modifier = Modifier.fillMaxSize().background(color = Color.White),
        horizontalAlignment = Alignment.CenterHorizontally)
    {
        Spacer(modifier = Modifier.weight(1f))
        NavigationBar(tonalElevation = 4.dp,
            containerColor = color

        ){

            Box(modifier = Modifier
                .padding(start = 5.dp, end = 5.dp)
            ) {
                Row {
                    //--------->
                    Spacer(modifier = Modifier.padding(start = 10.dp))
                    Column {
                        Image(
                            painter = painterResource(id = R.drawable.home),
                            contentDescription = "home",
                            modifier = Modifier.size(50.dp).padding(start = 5.dp)
                                .clickable{ navController.navigate("m_page1") }
                        )
                        Text(text = "Home", modifier = Modifier.padding(start = 5.dp))

                    }
                    //----------->
                    Spacer(modifier = Modifier.padding(start = 10.dp))
                    Column(modifier = Modifier.padding(start = 10.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.workout),
                            contentDescription = "Workout",
                            modifier = Modifier.size(50.dp).padding(start = 10.dp)
                                .clickable{ navController.navigate("m_page2") }

                        )
                        Text(text = "Workout", modifier = Modifier.padding(start = 5.dp))

                    }
                    //------------>
                    Spacer(modifier = Modifier.padding(start = 10.dp))
                    Column {
                        Image(
                            painter = painterResource(id = R.drawable.diet),
                            contentDescription = "Diet",
                            modifier = Modifier.size(50.dp).padding(start = 5.dp)
                                .clickable{ navController.navigate("m_page3") }
                        )
                        Text(text = "Diet", modifier = Modifier.padding(start = 12.dp))
                    }
                    //------
                    Spacer(modifier = Modifier.padding(start = 10.dp))
                    Column(modifier = Modifier.padding(start = 10.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.progress),
                            contentDescription = "Progress",
                            modifier = Modifier.size(50.dp).padding(start = 10.dp)
                                .clickable{ navController.navigate("m_page4") }
                        )
                        Text(text = "Progress", modifier = Modifier.padding(start = 5.dp))
                    }
                    //------------>
                    Spacer(modifier = Modifier.padding(start = 10.dp))
                    Column(modifier = Modifier.padding(start = 10.dp)) {
                        Image(
                            painter = painterResource(id = R.drawable.profile),
                            contentDescription = "Profile",
                            modifier = Modifier.size(50.dp).padding(start = 5.dp)
                                .clickable{ navController.navigate("m_page5") }
                        )
                        Text(text = "Profile", modifier = Modifier.padding(start = 5.dp))
                    }
                    Spacer(modifier = Modifier.padding(start = 10.dp))
                }
            }
        }
    }
}


//-------------------------------------------------------
//preview
@Preview
@Composable
fun Main_pagePreview(){
    GYMTheme {
        val navController = rememberNavController()
        Main_page(navController = navController)
    }
}