package com.example.gym.datavalues

import androidx.core.app.GrammaticalInflectionManagerCompat
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase

@Entity(tableName = "userdata")
data class Userdetails(
    @PrimaryKey(autoGenerate = true)
    val gender: String,
    val gov: String,
    val wlv: String,
    val bdy: String,
    val push0up: String,
    val run: String,
    val owv: String
)

@Dao
interface UserDao {
    @Insert
    suspend fun insertUser(user: Userdetails)
    @Query("SELECT * FROM userdata")
    suspend fun getAllUsers(): List<Userdetails>
}
@Database(entities = [Userdetails::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
}