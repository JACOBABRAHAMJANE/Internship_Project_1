package com.example.gym.options

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
//import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
//import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.gym.R
import com.example.gym.ui.theme.GYMTheme
import androidx.compose.foundation.lazy.rememberLazyListState
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import com.example.gym.SharedViewModel


//-------------------------------------------------------------
@Composable
fun Option4(navController: NavController, viewModel: SharedViewModel)
{
    val pcolor = colorResource(id = R.color.white)
    val bdy = (1900..2030).toList()
    var selectYear by remember { mutableIntStateOf(0) }

    Column (
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(top = 170.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    )
    {
        Text(text = " 5What’s your birth year?", fontSize = 24.sp,
            textDecoration = TextDecoration.Underline)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(pcolor,
                    shape = RoundedCornerShape( topStart = 60.dp, topEnd = 60.dp))
                .padding(top = 30.dp),
            horizontalAlignment = Alignment.CenterHorizontally,

            ) {
            Box(contentAlignment = Alignment.Center,
                modifier = Modifier
                    .height(250.dp)
                    .width(100.dp)
                    .padding(top = 50 .dp)
                    .border(2.dp, color = Color.Black , RoundedCornerShape(16.dp)))
            {
                LazyColumn(horizontalAlignment = Alignment.CenterHorizontally)
                {
                    itemsIndexed(bdy) { index, bdy ->
                        Text(text = bdy.toString(),
                        fontSize = 25.sp,
                        modifier = Modifier
                            .padding(vertical = 10.dp)
                            .clickable {
                                selectYear = index
                                viewModel.bdy0value(bdy.toString())
                            },
                        color = if (index == selectYear) Color.Blue else Color.Gray
                        )
                    }

                }


            }
            Text(text = "\n\nSelected year:",
                fontSize = 22.sp)
            Box {
                if (selectYear != 0) {
                    Text(
                        text =  "${bdy[selectYear]}",
                        fontSize = 22.sp,
                        color = Color.Blue,
                        modifier = Modifier.padding(top = 20.dp),
                        textDecoration = TextDecoration.Underline
                    )
                }
            }

            Image(
                painter = painterResource(id = R.drawable.img_next),
                contentDescription = "next",
                modifier = Modifier
                    .size(150.dp)
                    .padding(top = 100.dp)
                    .clickable{ navController.navigate("option_5") }
            )
        }
    }
}
//-------------------------------------------------------
//preview
@Preview
@Composable
fun Option4Preview(){
    GYMTheme {
        val navController = rememberNavController()
        Option4(navController = navController, viewModel = SharedViewModel())
    }
}