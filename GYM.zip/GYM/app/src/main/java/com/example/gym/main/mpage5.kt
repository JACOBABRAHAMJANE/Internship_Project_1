package com.example.gym.main


import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.gym.R
import com.example.gym.ui.theme.GYMTheme
//-------------------------------------------------------------
@Composable
fun Main_page_5(navController: NavController)
{
    Column (modifier = Modifier.fillMaxSize().background(color = Color.White))
    {
        Text(text = "profile")
        Main_page(navController = navController)
    }
    Image(
        painter = painterResource(id = R.drawable.img_next),
        contentDescription = "next",
        modifier = Modifier
            .size(150.dp)
            .padding(top = 100.dp)
            .clickable{ navController.navigate("m_page1") }
    )
}
//-------------------------------------------------------
//preview
@Preview
@Composable
fun Main_page_5Preview(){
    GYMTheme {
        val navController = rememberNavController()
        Main_page_5(navController = navController)

    }
}