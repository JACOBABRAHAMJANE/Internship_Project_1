    package com.example.gym.options


    import androidx.compose.foundation.Image
    import androidx.compose.foundation.background
    import androidx.compose.foundation.clickable
    import androidx.compose.foundation.interaction.MutableInteractionSource
    import androidx.compose.foundation.layout.Column
    import androidx.compose.foundation.layout.Spacer
    import androidx.compose.foundation.layout.fillMaxSize
    import androidx.compose.foundation.layout.padding
    import androidx.compose.foundation.layout.size
    import androidx.compose.foundation.shape.RoundedCornerShape
    import androidx.compose.material3.Text
    import androidx.compose.runtime.Composable
    import androidx.compose.runtime.getValue
    import androidx.compose.runtime.mutableStateOf
    import androidx.compose.runtime.remember
    import androidx.compose.runtime.setValue
    import androidx.compose.ui.Alignment
    import androidx.compose.ui.Modifier
    import androidx.compose.ui.graphics.Color
    import androidx.compose.ui.res.colorResource
    import androidx.compose.ui.res.painterResource
    import androidx.compose.ui.text.style.TextDecoration
    import androidx.compose.ui.tooling.preview.Preview
    import androidx.compose.ui.unit.dp
    import androidx.compose.ui.unit.sp
    import androidx.navigation.NavController
    import androidx.navigation.compose.rememberNavController
    import com.example.gym.R
    import com.example.gym.SharedViewModel
    import com.example.gym.ui.theme.GYMTheme
    //-------------------------------------------------------------
    @Composable
    fun Option2(navController: NavController, viewModel: SharedViewModel)
    {
        val pcolor = colorResource(id = R.color.white)
        var selected by remember { mutableStateOf("") }
        var wl = "Weight Lose"
        var mb  = "Muscle Build"
        var kf = "Keep fit"
        Column (
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White)
                .padding(top = 170.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        )
        {
            Text(text = " 3what’s Your main goal", fontSize = 24.sp,
                textDecoration = TextDecoration.Underline)
            Spacer(modifier = Modifier.padding(top = 25.dp))
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(pcolor,
                        shape = RoundedCornerShape( topStart = 60.dp, topEnd = 60.dp))
                    .padding(top = 50.dp),
                horizontalAlignment = Alignment.CenterHorizontally,

                ){
                Spacer( modifier = Modifier.padding(top = 50.dp))

                Text( text = wl, fontSize = 20.sp,
                    color = if (selected == wl) Color(0xFF7A20C9)else Color(0xFF000000),
                    modifier = Modifier
                        .clickable{selected = wl
                        viewModel.goal0value("Weight Lose")}
                      //  .background(Color.White,shape = RoundedCornerShape(20.dp))
                      //  .border(1.5.dp, Color(0xFF595050),shape = RoundedCornerShape(20.dp))
                )
                Spacer( modifier = Modifier.padding(top = 50.dp))

                Text( text = mb, fontSize = 20.sp,
                    color = if (selected == mb) Color(0xFF7A20C9) else Color(0xFF000000),
                    modifier = Modifier
                        .clickable{selected = mb
                        viewModel.goal0value("Muscle Build")}
                      //  .background(Color.White,shape = RoundedCornerShape(20.dp))
                      //  .border(1.5.dp, Color(0xFF595050),shape = RoundedCornerShape(20.dp))
                )
                Spacer( modifier = Modifier.padding(top = 50.dp))

                Text( text = kf, fontSize = 20.sp,
                    color = if (selected == kf) Color(0xFF7A20C9) else Color(0xFF000000),
                    modifier = Modifier
                        .clickable{selected = kf
                        viewModel.goal0value("Keep fit")}
                      //  .background(Color.White,shape = RoundedCornerShape(20.dp))
                      /*  .border(1.5.dp, Color(0xFF595050),
                            shape = RoundedCornerShape(20.dp))
                        .height(40.dp)*/
                )
                Text(text ="\n\n")
                Image(
                    painter = painterResource(id = R.drawable.img_next),
                    contentDescription = "next",
                    modifier = Modifier
                        .size(150.dp)
                        .padding(top = 50.dp)
                        .clickable{ navController.navigate("option_3") }
                )
            }
        }
    }
    //-------------------------------------------------------
    //preview
    @Preview
    @Composable
    fun Option2Preview(){
        GYMTheme {
            val navController = rememberNavController()
            Option2(navController = navController,viewModel = SharedViewModel())
        }
    }
