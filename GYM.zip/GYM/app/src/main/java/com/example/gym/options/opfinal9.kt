package com.example.gym.options

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.gym.R
import com.example.gym.ui.theme.GYMTheme

//-------------------------------------------------------------
@Composable
fun Plan_page(navController: NavController)
{
    val pcolor = colorResource(id = R.color.white)
    Column (
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(top = 170.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    )
    {
        Text(text = "final page", fontSize = 24.sp,
            textDecoration = TextDecoration.Underline)
        Spacer(modifier = Modifier.padding(top = 25.dp))
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(pcolor,
                    shape = androidx.compose.foundation.shape.RoundedCornerShape( topStart = 60.dp, topEnd = 60.dp))
                .padding(top = 30.dp),
            horizontalAlignment = Alignment.CenterHorizontally,

            ){

            Image(
                painter = painterResource(id = R.drawable.img_next),
                contentDescription = "next",
                modifier = Modifier
                    .size(150.dp)
                    .padding(top = 100.dp)
                    .clickable{ navController.navigate("m_page1") }
            )

        }
    }
}
//-------------------------------------------------------
//preview
@Preview
@Composable
fun Plan_pagePreview(){
    GYMTheme {
        val navController = rememberNavController()
        Plan_page(navController = navController)
    }
}