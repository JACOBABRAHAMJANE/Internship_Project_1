package com.example.gym.options

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.gym.R
import com.example.gym.ui.theme.GYMTheme

//-------------------------------------------------------------
@Composable
fun Plan_page(navController: NavController)
{
    val pcolor = colorResource(id = R.color.white)
    val lcolor = colorResource(id = R.color.purple_200)

    Column (
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(top = 170.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    )
    {
        Text(text = "final page", fontSize = 24.sp,
            textDecoration = TextDecoration.Underline)
        Spacer(modifier = Modifier.padding(top = 25.dp))
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(pcolor,
                    shape = androidx.compose.foundation.shape.RoundedCornerShape( topStart = 60.dp, topEnd = 60.dp))
                .padding(top = 30.dp),
            horizontalAlignment = Alignment.CenterHorizontally,

            ){
            Spacer(modifier = Modifier.padding(top = 150.dp) )
            loadPlan()

            Image(
                painter = painterResource(id = R.drawable.img_next),
                contentDescription = "next",
                modifier = Modifier
                    .size(150.dp)
                    .padding(top = 100.dp)
                    .clickable{ navController.navigate("m_page1") }
            )

        }
    }
}
@Composable
fun loadPlan(){

        val transition = rememberInfiniteTransition()
        val shimmerX = transition.animateFloat(
            initialValue = 0f,
            targetValue = 1000f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 1200, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            )
        )

        val shimmerBrush = Brush.linearGradient(
            colors = listOf(Color.LightGray, Color.Cyan, Color.LightGray),
            start = Offset(shimmerX.value - 300f, 0f),
            end = Offset(shimmerX.value, 0f)
        )

        Text(
            text = "Starting your plan",
            fontSize = 40.sp,
            style = TextStyle(brush = shimmerBrush),
            modifier = Modifier.padding(vertical = 20.dp)
                .height(50.dp)
                .border( 1.dp, Color.Black, RoundedCornerShape(50.dp))
        )
    }

//-------------------------------------------------------
//preview
@Preview
@Composable
fun Plan_pagePreview(){
    GYMTheme {
        val navController = rememberNavController()
        Plan_page(navController = navController)
    }
}