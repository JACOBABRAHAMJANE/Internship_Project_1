package com.example.gym.options

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.gym.R
import com.example.gym.SharedViewModel
import com.example.gym.ui.theme.GYMTheme

//-------------------------------------------------------------
@Composable
fun Option8(navController: NavController, viewModel: SharedViewModel)
{
    val pcolor = colorResource(id = R.color.white)
    val values = viewModel.gender.collectAsState().value
    val values1 = viewModel.gov.collectAsState().value
    val values2 = viewModel.wlv.collectAsState().value
    val values3 = viewModel.bdy.collectAsState().value
    val values4 = viewModel.push0up.collectAsState().value
    val values5 = viewModel.run.collectAsState().value
    val values6 = viewModel.owv.collectAsState().value

    Column (
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(top = 170.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    )
    {
        Text(text = "9 details", fontSize = 24.sp,
            textDecoration = TextDecoration.Underline)
        Spacer(modifier = Modifier.padding(top = 25.dp))
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(pcolor,
                    shape = androidx.compose.foundation.shape.RoundedCornerShape( topStart = 60.dp, topEnd = 60.dp))
                .padding(top = 30.dp),
            horizontalAlignment = Alignment.CenterHorizontally,

            ){
            Box (modifier =  Modifier
                .padding(top = 100.dp)
                .size(200.dp)
                .background( Color.Gray)){
                Text(text =  "Gender: $values", fontSize = 20.sp, color = Color.Blue)
                Text(text =  "\ngoal:$values1 ", fontSize = 20.sp, color = Color.Blue)
                Text(text =  "\n\nweight:$values2 ", fontSize = 20.sp, color = Color.Blue)
                Text(text =  "\n\n\nbody type:$values3 ", fontSize = 20.sp, color = Color.Blue)
                Text(text =  "\n\n\n\npush up:$values4 ", fontSize = 20.sp, color = Color.Blue)
                Text(text =  "\n\n\n\n\nrun:$values5 ", fontSize = 20.sp, color = Color.Blue)
                Text(text =  "\n\n\n\n\n\nworkout:$values6 ", fontSize = 20.sp, color = Color.Blue)

            }


            Image(
                painter = painterResource(id = R.drawable.img_next),
                contentDescription = "next",
                modifier = Modifier
                    .size(150.dp)
                    .padding(top = 100.dp)
                    .clickable{ navController.navigate("option_9") }
            )

        }
    }
}
//-------------------------------------------------------
//preview
@Preview
@Composable
fun Option8Preview(){
    GYMTheme {
        val navController = rememberNavController()
        val viewModel = remember { SharedViewModel() }
        Option8(navController = navController,viewModel = viewModel)
    }
}