package com.example.gym.options

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import com.example.gym.ui.theme.GYMTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.gym.R
import com.example.gym.SharedViewModel


//-------------------------------------------------------------
@Composable
fun Option1(navController: NavController, viewModel: SharedViewModel)
{
    var sgender by remember { mutableStateOf("") }
    val pcolor = colorResource(id = R.color.white)
    Column (
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(top = 170.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    )
    {
        Text(text = "2what’s your gender", fontSize = 24.sp,
            textDecoration = TextDecoration.Underline)
        Spacer(modifier = Modifier.padding(top = 25.dp))
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(pcolor,
                    shape = androidx.compose.foundation.shape.RoundedCornerShape( topStart = 60.dp, topEnd = 60.dp))
                .padding(top = 30.dp),
            horizontalAlignment = Alignment.CenterHorizontally,

        ){
            Image(
                painter = painterResource(
                    id = if (sgender == "male") R.drawable.img_male_s
                    else R.drawable.img_male
                ),
                contentDescription = "male",
                modifier = Modifier
                    .size(150.dp)
                    .padding(top = 50.dp)
                    .clickable (
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ){
                        sgender = "male"
                        viewModel.gender0value ("male")
                    }
            )

            Image(
                painter = painterResource(
                    id = if (sgender == "female") R.drawable.img_female_s
                    else R.drawable.img_female
                ),
                contentDescription = "female",
                modifier = Modifier
                    .size(150.dp)
                    .padding(top = 50.dp)
                    .clickable(interactionSource = remember { MutableInteractionSource() },
                        indication = null ){
                        sgender = "female"

                        viewModel.gender0value("female")
                    }
            )
                Image(
                    painter = painterResource(id = R.drawable.img_next),
                    contentDescription = "next",
                    modifier = Modifier
                        .size(150.dp)
                        .padding(top = 50.dp)
                        .clickable{ navController.navigate("option_2") }
                )
        }
    }
}

//-------------------------------------------------------
//preview
@Preview
@Composable
fun Option1Preview(){
    GYMTheme {
        val navController = rememberNavController()
        val viewModel = remember { SharedViewModel() }
        Option1(navController = navController,viewModel = viewModel)
    }
}